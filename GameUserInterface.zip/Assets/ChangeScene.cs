using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ChangeScene : MonoBehaviour
{
    public AudioSource ButtonAudio;
    public AudioSource BackAudio;
    void Start()
    {
        ButtonAudio.Pause();
    }
    public void PlayGame()
    {
        ButtonAudio.Play();
        //SceneManager.LoadScene("");
    }
    public void Settings()
    {
        ButtonAudio.Play();
        
    }
    public void ExitGame()
    {
        ButtonAudio.Play();
        Debug.Log("Game has been Quit");
        Application.Quit();
    }
}
